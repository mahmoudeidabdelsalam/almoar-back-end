<?php
/**
 * Plugin Name: Custom Gravity Forms API
 * Description: REST API endpoint for submitting Gravity Forms from a Headless frontend.
 * Version: 1.0.0
 * Author: Mahmoud Eid
 * Author URI: https://mahmoud-eid.pages.dev/
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit;
}

class Custom_Gravity_Forms_API
{
    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Register REST API routes
     */
    public function register_routes()
    {
        register_rest_route(
            'custom/v1',
            '/gravity-form',
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'submit_form'],
                'permission_callback' => '__return_true',
                'args'                => [
                    'formId' => [
                        'required'          => true,
                        'sanitize_callback' => 'absint',
                        'validate_callback' => function ($value) {
                            return absint($value) > 0;
                        },
                    ],
                    'fields' => [
                        'required' => true,
                        'validate_callback' => function ($value) {
                            return is_array($value);
                        },
                    ],
                ],
            ]
        );
    }

    /**
     * Submit Gravity Form
     */
    public function submit_form(WP_REST_Request $request)
    {
        // Check Gravity Forms
        if (!class_exists('GFAPI')) {
            return new WP_Error(
                'gravity_forms_missing',
                'Gravity Forms is not available.',
                [
                    'status' => 500,
                ]
            );
        }

        $form_id = absint($request->get_param('formId'));
        $fields  = $request->get_param('fields');

        // Validate form ID
        if (!$form_id) {
            return new WP_Error(
                'invalid_form_id',
                'Invalid form ID.',
                [
                    'status' => 400,
                ]
            );
        }

        // Get Gravity Form
        $form = GFAPI::get_form($form_id);

        if (!$form) {
            return new WP_Error(
                'form_not_found',
                'Gravity Form not found.',
                [
                    'status' => 404,
                ]
            );
        }

        if (!is_array($fields)) {
            return new WP_Error(
                'invalid_fields',
                'Invalid form fields.',
                [
                    'status' => 400,
                ]
            );
        }

        /*
         * Build Gravity Forms entry
         */
        $entry = [];

        foreach ($fields as $field_id => $value) {

            // Field ID can be "1", "2", "3"
            $field_id = (string) $field_id;

            /*
             * Don't blindly sanitize everything because
             * Gravity Forms fields can have different formats.
             */
            if (is_array($value)) {
                $entry[$field_id] = array_map(
                    'sanitize_text_field',
                    $value
                );
            } else {
                $entry[$field_id] = sanitize_textarea_field($value);
            }
        }

        /*
         * Submit through Gravity Forms
         */
        $result = GFAPI::submit_form(
            $form_id,
            $entry
        );

        /*
         * Gravity Forms returned WP_Error
         */
        if (is_wp_error($result)) {
            return new WP_Error(
                'gravity_forms_error',
                $result->get_error_message(),
                [
                    'status' => 500,
                ]
            );
        }

        /*
         * Validation failed
         */
        if (
            isset($result['is_valid']) &&
            !$result['is_valid']
        ) {
            return new WP_Error(
                'validation_failed',
                'Please check the form fields.',
                [
                    'status' => 422,
                    'errors' => $result['validation_messages'] ?? [],
                ]
            );
        }

        /*
         * Success
         */
        return new WP_REST_Response(
            [
                'success' => true,
                'entryId' => $result['entry_id'] ?? null,
                'message' => 'Your form has been submitted successfully.',
            ],
            200
        );
    }
}

new Custom_Gravity_Forms_API();